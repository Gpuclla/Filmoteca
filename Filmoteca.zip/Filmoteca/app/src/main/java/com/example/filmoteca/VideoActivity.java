package com.example.filmoteca;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.VideoView;

import java.util.List;

public class VideoActivity extends AppCompatActivity {

    VideoView movie;
    TextView titulo,sinopsis;
    List<Pelicula> lst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        movie= findViewById(R.id.PeliView);
        titulo= findViewById(R.id.txtTitulo);
        sinopsis=findViewById(R.id.txtContenido);

        Pelicula p=lst.get(i);

        titulo.setText();
    }
}