package com.example.filmoteca;

public class Pelicula {
    public int id;
    public int imagen;
    public String titulo;
    public String desc;

    public Pelicula(int id, int imagen, String titulo, String desc) {
        this.id = id;
        this.imagen = imagen;
        this.titulo = titulo;
        desc = desc;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
